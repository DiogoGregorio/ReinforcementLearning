import argparse
from all.experiments import plot_returns_100

plot_returns_100('./runs', timesteps=2e6)
